import type { DataRow, ColumnInfo, QualityResult, QualityIssue } from '../types';

export function inferColumnType(values: (string | number | boolean | null)[]): ColumnInfo['type'] {
  const nonNull = values.filter(v => v !== null && v !== undefined && v !== '');
  if (nonNull.length === 0) return 'string';

  const numCount = nonNull.filter(v => !isNaN(Number(v)) && v !== '').length;
  if (numCount / nonNull.length > 0.8) return 'number';

  const boolCount = nonNull.filter(v =>
    typeof v === 'boolean' || ['true', 'false', '0', '1', 'yes', 'no'].includes(String(v).toLowerCase())
  ).length;
  if (boolCount / nonNull.length > 0.8) return 'boolean';

  const dateCount = nonNull.filter(v => !isNaN(Date.parse(String(v))) && String(v).length > 5).length;
  if (dateCount / nonNull.length > 0.7) return 'date';

  return 'string';
}

export function getColumnInfo(data: DataRow[], colName: string): ColumnInfo {
  const values = data.map(row => row[colName]);
  const nullCount = values.filter(v => v === null || v === undefined || v === '').length;
  const nonNull = values.filter(v => v !== null && v !== undefined && v !== '');
  const uniqueValues = new Set(nonNull.map(String));

  return {
    name: colName,
    type: inferColumnType(values),
    nullCount,
    nullPercent: data.length > 0 ? Math.round((nullCount / data.length) * 1000) / 10 : 0,
    uniqueCount: uniqueValues.size,
    sample: nonNull.slice(0, 3) as (string | number | null)[],
  };
}

export function runQualityAnalysis(data: DataRow[]): QualityResult {
  if (data.length === 0) return { score: 0, issues: [], nullTotal: 0, dupTotal: 0 };

  const columns = Object.keys(data[0]);
  const issues: QualityIssue[] = [];
  let score = 100;
  let nullTotal = 0;

  // Check each column for nulls
  for (const col of columns) {
    const nullCount = data.filter(row => row[col] === null || row[col] === undefined || row[col] === '').length;
    if (nullCount > 0) {
      nullTotal += nullCount;
      const pct = Math.round((nullCount / data.length) * 1000) / 10;
      const severity: QualityIssue['severity'] = pct > 20 ? 'error' : 'warning';
      issues.push({
        column: col,
        type: 'Missing values',
        detail: `${nullCount} null values (${pct}%)`,
        severity,
      });
      score -= Math.min(15, pct * 0.4);
    }
  }

  // Check duplicates
  const seen = new Set<string>();
  let dupCount = 0;
  for (const row of data) {
    const key = JSON.stringify(row);
    if (seen.has(key)) dupCount++;
    else seen.add(key);
  }
  if (dupCount > 0) {
    const pct = Math.round((dupCount / data.length) * 1000) / 10;
    issues.push({
      column: '— all rows —',
      type: 'Duplicate rows',
      detail: `${dupCount} duplicates (${pct}%)`,
      severity: pct > 5 ? 'error' : 'warning',
    });
    score -= Math.min(20, pct * 2);
  }

  // Check type mismatches
  for (const col of columns) {
    const values = data.map(r => r[col]).filter(v => v !== null && v !== undefined && v !== '');
    const allStrings = values.every(v => typeof v === 'string');
    if (allStrings) {
      const numericCount = values.filter(v => !isNaN(Number(v)) && String(v).trim() !== '').length;
      if (numericCount / values.length > 0.7) {
        issues.push({
          column: col,
          type: 'Type mismatch',
          detail: 'Numeric values stored as text',
          severity: 'warning',
        });
        score -= 5;
      }
    }
  }

  // Check for whitespace issues
  for (const col of columns) {
    const wsCount = data.filter(row => {
      const v = row[col];
      return typeof v === 'string' && v !== v.trim();
    }).length;
    if (wsCount > 0) {
      issues.push({
        column: col,
        type: 'Whitespace',
        detail: `${wsCount} values with leading/trailing spaces`,
        severity: 'info',
      });
    }
  }

  // Check for outliers in numeric columns
  for (const col of columns) {
    const nums = data
      .map(r => Number(r[col]))
      .filter(n => !isNaN(n));
    if (nums.length > 10) {
      const sorted = [...nums].sort((a, b) => a - b);
      const q1 = sorted[Math.floor(sorted.length * 0.25)];
      const q3 = sorted[Math.floor(sorted.length * 0.75)];
      const iqr = q3 - q1;
      if (iqr > 0) {
        const outliers = nums.filter(n => n < q1 - 3 * iqr || n > q3 + 3 * iqr).length;
        if (outliers > 0) {
          issues.push({
            column: col,
            type: 'Statistical outliers',
            detail: `${outliers} values beyond 3×IQR`,
            severity: 'info',
          });
        }
      }
    }
  }

  return {
    score: Math.max(0, Math.round(score)),
    issues,
    nullTotal,
    dupTotal: dupCount,
  };
}

export function getBasicStats(data: DataRow[], col: string) {
  const nums = data.map(r => Number(r[col])).filter(n => !isNaN(n));
  if (nums.length === 0) return null;

  const sorted = [...nums].sort((a, b) => a - b);
  const sum = nums.reduce((a, b) => a + b, 0);
  const mean = sum / nums.length;
  const median = sorted.length % 2 === 0
    ? (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
    : sorted[Math.floor(sorted.length / 2)];
  const variance = nums.reduce((acc, n) => acc + (n - mean) ** 2, 0) / nums.length;
  const std = Math.sqrt(variance);
  const skewness = nums.reduce((acc, n) => acc + ((n - mean) / std) ** 3, 0) / nums.length;

  return {
    count: nums.length,
    mean: Math.round(mean * 1000) / 1000,
    median: Math.round(median * 1000) / 1000,
    std: Math.round(std * 1000) / 1000,
    min: sorted[0],
    max: sorted[sorted.length - 1],
    skewness: Math.round(skewness * 1000) / 1000,
    q1: sorted[Math.floor(sorted.length * 0.25)],
    q3: sorted[Math.floor(sorted.length * 0.75)],
  };
}

export function getValueCounts(data: DataRow[], col: string, topN = 10): { value: string; count: number }[] {
  const counts: Record<string, number> = {};
  for (const row of data) {
    const v = String(row[col] ?? '(null)');
    counts[v] = (counts[v] || 0) + 1;
  }
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, topN)
    .map(([value, count]) => ({ value, count }));
}

export function getCorrelationMatrix(data: DataRow[], numCols: string[]): { cols: string[]; matrix: number[][] } {
  const vectors: Record<string, number[]> = {};
  for (const col of numCols) {
    vectors[col] = data.map(r => Number(r[col])).filter(n => !isNaN(n));
  }

  const validCols = numCols.filter(c => vectors[c].length > 2);
  const matrix: number[][] = [];

  for (const c1 of validCols) {
    const row: number[] = [];
    for (const c2 of validCols) {
      const v1 = vectors[c1];
      const v2 = vectors[c2];
      const n = Math.min(v1.length, v2.length);
      const m1 = v1.slice(0, n).reduce((a, b) => a + b, 0) / n;
      const m2 = v2.slice(0, n).reduce((a, b) => a + b, 0) / n;

      let cov = 0, s1 = 0, s2 = 0;
      for (let i = 0; i < n; i++) {
        cov += (v1[i] - m1) * (v2[i] - m2);
        s1 += (v1[i] - m1) ** 2;
        s2 += (v2[i] - m2) ** 2;
      }
      const r = s1 > 0 && s2 > 0 ? cov / Math.sqrt(s1 * s2) : 0;
      row.push(Math.round(r * 100) / 100);
    }
    matrix.push(row);
  }

  return { cols: validCols, matrix };
}

export function applyOperation(
  data: DataRow[],
  action: string,
  column?: string,
  options: Record<string, string> = {}
): { data: DataRow[]; log: string } {
  let result = [...data.map(r => ({ ...r }))];
  let log = '';

  switch (action) {
    case 'drop_nulls': {
      if (column) {
        const before = result.length;
        result = result.filter(r => r[column] !== null && r[column] !== undefined && r[column] !== '');
        log = `Dropped ${before - result.length} rows with nulls in ${column}`;
      }
      break;
    }
    case 'fill_nulls': {
      if (column) {
        const method = options.method || 'value';
        const nums = result.map(r => Number(r[column])).filter(n => !isNaN(n));
        let fillVal: string | number = options.value || '';
        if (method === 'mean' && nums.length > 0) fillVal = Math.round((nums.reduce((a, b) => a + b, 0) / nums.length) * 100) / 100;
        else if (method === 'median' && nums.length > 0) {
          const s = [...nums].sort((a, b) => a - b);
          fillVal = s.length % 2 === 0 ? (s[s.length / 2 - 1] + s[s.length / 2]) / 2 : s[Math.floor(s.length / 2)];
        } else if (method === 'mode') {
          const counts: Record<string, number> = {};
          result.forEach(r => { const v = String(r[column] ?? ''); if (v) counts[v] = (counts[v] || 0) + 1; });
          fillVal = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || '';
        }
        result.forEach(r => { if (r[column] === null || r[column] === undefined || r[column] === '') r[column] = fillVal; });
        log = `Filled nulls in ${column} with ${method} (${fillVal})`;
      }
      break;
    }
    case 'drop_duplicates': {
      const seen = new Set<string>();
      const before = result.length;
      result = result.filter(r => {
        const key = JSON.stringify(r);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      log = `Removed ${before - result.length} duplicate rows`;
      break;
    }
    case 'trim_whitespace': {
      if (column) {
        result.forEach(r => { if (typeof r[column] === 'string') r[column] = r[column].trim(); });
        log = `Trimmed whitespace in ${column}`;
      }
      break;
    }
    case 'convert_type': {
      if (column) {
        const t = options.targetType || 'number';
        if (t === 'number') {
          result.forEach(r => { const n = Number(r[column]); r[column] = isNaN(n) ? null : n; });
        }
        log = `Converted ${column} to ${t}`;
      }
      break;
    }
    case 'drop_column': {
      if (column) {
        result.forEach(r => delete r[column]);
        log = `Dropped column ${column}`;
      }
      break;
    }
    case 'uppercase': {
      if (column) {
        result.forEach(r => { if (typeof r[column] === 'string') r[column] = (r[column] as string).toUpperCase(); });
        log = `Uppercased ${column}`;
      }
      break;
    }
    case 'lowercase': {
      if (column) {
        result.forEach(r => { if (typeof r[column] === 'string') r[column] = (r[column] as string).toLowerCase(); });
        log = `Lowercased ${column}`;
      }
      break;
    }
    case 'rename_column': {
      if (column && options.newName) {
        result.forEach(r => { r[options.newName!] = r[column]; delete r[column]; });
        log = `Renamed ${column} to ${options.newName}`;
      }
      break;
    }
    case 'replace_value': {
      if (column && options.oldValue !== undefined) {
        result.forEach(r => { if (String(r[column]) === options.oldValue) r[column] = options.newValue || ''; });
        log = `Replaced '${options.oldValue}' with '${options.newValue}' in ${column}`;
      }
      break;
    }
    case 'cap_outliers': {
      if (column) {
        const nums = result.map(r => Number(r[column])).filter(n => !isNaN(n));
        if (nums.length > 4) {
          const sorted = [...nums].sort((a, b) => a - b);
          const q1 = sorted[Math.floor(sorted.length * 0.25)];
          const q3 = sorted[Math.floor(sorted.length * 0.75)];
          const iqr = q3 - q1;
          const lo = q1 - 3 * iqr;
          const hi = q3 + 3 * iqr;
          let capped = 0;
          result.forEach(r => {
            const n = Number(r[column]);
            if (!isNaN(n)) {
              if (n < lo) { r[column] = lo; capped++; }
              else if (n > hi) { r[column] = hi; capped++; }
            }
          });
          log = `Capped ${capped} outliers in ${column}`;
        }
      }
      break;
    }
    default:
      log = `Unknown action: ${action}`;
  }

  return { data: result, log };
}
