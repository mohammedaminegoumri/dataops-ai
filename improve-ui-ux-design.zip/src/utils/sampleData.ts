import type { DataRow } from '../types';

const regions = ['North', 'South', 'East', 'West', 'Central'];
const products = ['Widget A', 'Widget B', 'Gadget X', 'Gadget Y', 'Module Z', 'Module W'];
const statuses = ['Active', 'Pending', 'Completed', 'Cancelled'];
const categories = ['Electronics', 'Software', 'Hardware', 'Services', 'Consulting'];

function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function generateSampleData(rows = 200): DataRow[] {
  const data: DataRow[] = [];
  const startDate = new Date('2024-01-01');

  for (let i = 0; i < rows; i++) {
    const date = new Date(startDate.getTime() + rand(0, 365) * 86400000);
    const quantity = rand(1, 50);
    const unitPrice = rand(10, 500);
    const revenue = quantity * unitPrice;
    const cost = Math.round(revenue * (0.3 + Math.random() * 0.4));

    const row: DataRow = {
      id: i + 1,
      date: date.toISOString().split('T')[0],
      region: pick(regions),
      product: pick(products),
      category: pick(categories),
      status: pick(statuses),
      quantity,
      unit_price: unitPrice,
      revenue,
      cost,
      profit: revenue - cost,
      customer_rating: Math.round((3 + Math.random() * 2) * 10) / 10,
    };

    // Introduce some data quality issues
    if (i % 17 === 0) row.region = '';          // Missing values
    if (i % 23 === 0) row.revenue = null;       // Null values
    if (i % 31 === 0) row.product = '  Widget A '; // Whitespace
    if (i % 41 === 0) row.quantity = -rand(1, 10) as number; // Negative outlier

    // Duplicate some rows
    if (i > 0 && i % 37 === 0) {
      data.push({ ...data[i - 1] });
    }

    data.push(row);
  }

  return data;
}
