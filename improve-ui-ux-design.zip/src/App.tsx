import { AppProvider, useApp } from './store';
import { OverviewTab } from './tabs/OverviewTab';
import { DataSourceTab } from './tabs/DataSourceTab';
import { DataQualityTab } from './tabs/DataQualityTab';
import { TransformationTab } from './tabs/TransformationTab';
import { AnalyticsTab } from './tabs/AnalyticsTab';
import { DocumentationTab } from './tabs/DocumentationTab';
import type { TabName } from './types';
import { cn } from '@/utils/cn';
import {
  LayoutDashboard, Database, Shield, Zap, BarChart3, FileText,
  Hexagon
} from 'lucide-react';

const TABS: { key: TabName; label: string; icon: typeof LayoutDashboard }[] = [
  { key: 'Overview', label: 'Overview', icon: LayoutDashboard },
  { key: 'Data Source', label: 'Data Source', icon: Database },
  { key: 'Data Quality', label: 'Quality', icon: Shield },
  { key: 'Transformation', label: 'Transform', icon: Zap },
  { key: 'Analytics', label: 'Analytics', icon: BarChart3 },
  { key: 'Documentation', label: 'Docs', icon: FileText },
];

function AppContent() {
  const { state, dispatch } = useApp();
  const { tab, data, quality, cleanLog, filename } = state;

  const hasData = data !== null;
  const issueCount = quality?.issues.length ?? 0;
  const opCount = cleanLog.length;

  const tabBadge = (key: TabName): number | null => {
    if (key === 'Data Quality' && issueCount > 0) return issueCount;
    if (key === 'Transformation' && opCount > 0) return opCount;
    return null;
  };

  const renderTab = () => {
    switch (tab) {
      case 'Overview': return <OverviewTab />;
      case 'Data Source': return <DataSourceTab />;
      case 'Data Quality': return <DataQualityTab />;
      case 'Transformation': return <TransformationTab />;
      case 'Analytics': return <AnalyticsTab />;
      case 'Documentation': return <DocumentationTab />;
      default: return <OverviewTab />;
    }
  };

  return (
    <div className="min-h-screen bg-[#fafbfc]">
      {/* Top navigation */}
      <header className="sticky top-0 z-50 bg-white/80 glass border-b border-slate-200/80">
        <div className="max-w-[1200px] mx-auto px-6">
          {/* Top bar */}
          <div className="h-14 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Hexagon className="w-7 h-7 text-blue-600" strokeWidth={2.5} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-2 h-2 bg-blue-600 rounded-full" />
                </div>
              </div>
              <div>
                <h1 className="text-[15px] font-bold text-slate-900 tracking-tight leading-none">
                  DataOps AI
                </h1>
                <p className="text-[10px] text-slate-400 font-medium tracking-wide mt-0.5">
                  INTELLIGENT DATA PIPELINE
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {hasData && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-lg">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse-dot" />
                  <span className="text-[11px] font-mono text-slate-500">
                    {filename} · {data.length.toLocaleString()} rows
                  </span>
                </div>
              )}
              <div className="text-[10px] font-mono text-slate-400 hidden md:block">
                by Mohammed Amine Goumri
              </div>
            </div>
          </div>

          {/* Tab navigation */}
          <nav className="flex items-center gap-0 -mb-px">
            {TABS.map(({ key, label, icon: Icon }) => {
              const isActive = tab === key;
              const badge = tabBadge(key);
              return (
                <button
                  key={key}
                  onClick={() => dispatch({ type: 'SET_TAB', tab: key })}
                  className={cn(
                    'relative flex items-center gap-2 px-4 py-3 text-[13px] font-medium transition-all duration-200 border-b-2 whitespace-nowrap',
                    isActive
                      ? 'text-blue-600 border-blue-600'
                      : 'text-slate-500 border-transparent hover:text-slate-700 hover:border-slate-300'
                  )}
                >
                  <Icon className={cn('w-4 h-4', isActive ? 'text-blue-600' : 'text-slate-400')} />
                  <span className="hidden sm:inline">{label}</span>
                  {badge !== null && (
                    <span
                      className={cn(
                        'min-w-[18px] h-[18px] flex items-center justify-center text-[10px] font-bold rounded-full px-1 font-mono',
                        isActive
                          ? 'bg-blue-100 text-blue-600'
                          : 'bg-slate-100 text-slate-500'
                      )}
                    >
                      {badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-[1200px] mx-auto px-6 py-8">
        {renderTab()}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 mt-16">
        <div className="max-w-[1200px] mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Hexagon className="w-4 h-4 text-slate-300" />
            <span className="text-[11px] text-slate-400">
              DataOps AI — Built by Mohammed Amine Goumri
            </span>
          </div>
          <span className="text-[11px] text-slate-300 font-mono">
            v1.0
          </span>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
