import { useState } from 'react';
import type { DataRow } from '../types';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface DataTableProps {
  data: DataRow[];
  maxRows?: number;
  compact?: boolean;
}

export function DataTable({ data, maxRows = 50, compact = false }: DataTableProps) {
  const [page, setPage] = useState(0);
  if (!data.length) return null;

  const columns = Object.keys(data[0]);
  const pageSize = maxRows;
  const totalPages = Math.ceil(data.length / pageSize);
  const pageData = data.slice(page * pageSize, (page + 1) * pageSize);

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50/80">
              {columns.map(col => (
                <th
                  key={col}
                  className={`text-left font-semibold text-[11px] uppercase tracking-[0.06em] text-slate-400 border-b border-slate-200 whitespace-nowrap ${compact ? 'px-3 py-2' : 'px-4 py-3'}`}
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageData.map((row, i) => (
              <tr
                key={i}
                className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition-colors"
              >
                {columns.map(col => (
                  <td
                    key={col}
                    className={`text-slate-700 whitespace-nowrap ${compact ? 'px-3 py-1.5 text-xs' : 'px-4 py-2.5 text-[13px]'}`}
                  >
                    {row[col] === null || row[col] === undefined || row[col] === '' ? (
                      <span className="text-slate-300 italic text-xs">null</span>
                    ) : (
                      <span className={typeof row[col] === 'number' ? 'font-mono' : ''}>
                        {String(row[col])}
                      </span>
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-50/50 border-t border-slate-200">
          <span className="text-xs text-slate-400 font-mono">
            {page * pageSize + 1}–{Math.min((page + 1) * pageSize, data.length)} of {data.length.toLocaleString()}
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage(p => Math.max(0, p - 1))}
              disabled={page === 0}
              className="p-1 rounded-md hover:bg-slate-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-4 h-4 text-slate-500" />
            </button>
            <span className="text-xs text-slate-500 font-mono px-2">
              {page + 1} / {totalPages}
            </span>
            <button
              onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
              className="p-1 rounded-md hover:bg-slate-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
