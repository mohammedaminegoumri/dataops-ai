import { cn } from '@/utils/cn';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface KPICardProps {
  label: string;
  value: string;
  subtitle?: string;
  delta?: string;
  direction?: 'up' | 'down' | 'flat';
  icon?: React.ReactNode;
  accentColor?: string;
}

export function KPICard({ label, value, subtitle, delta, direction = 'flat', icon, accentColor }: KPICardProps) {
  const DeltaIcon = direction === 'up' ? TrendingUp : direction === 'down' ? TrendingDown : Minus;
  const deltaColor = direction === 'up' ? 'text-emerald-600' : direction === 'down' ? 'text-red-600' : 'text-slate-400';

  return (
    <div className="group relative bg-white border border-slate-200/80 rounded-xl p-5 hover:border-slate-300 hover:shadow-md transition-all duration-200 overflow-hidden">
      {accentColor && (
        <div
          className="absolute top-0 left-0 w-full h-0.5"
          style={{ background: accentColor }}
        />
      )}
      <div className="flex items-start justify-between mb-3">
        <span className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-400">
          {label}
        </span>
        {icon && (
          <div className="p-1.5 rounded-lg bg-slate-50 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-colors">
            {icon}
          </div>
        )}
      </div>
      <div className="font-mono text-2xl font-bold text-slate-900 tracking-tight leading-none">
        {value}
      </div>
      {delta && (
        <div className={cn('flex items-center gap-1 mt-2 text-xs font-medium', deltaColor)}>
          <DeltaIcon className="w-3.5 h-3.5" />
          <span>{delta}</span>
        </div>
      )}
      {subtitle && (
        <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">{subtitle}</p>
      )}
    </div>
  );
}
