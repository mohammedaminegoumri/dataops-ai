export interface DataRow {
  [key: string]: string | number | boolean | null;
}

export interface ColumnInfo {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'mixed';
  nullCount: number;
  nullPercent: number;
  uniqueCount: number;
  sample: (string | number | null)[];
}

export interface QualityIssue {
  column: string;
  type: string;
  detail: string;
  severity: 'error' | 'warning' | 'info';
}

export interface QualityResult {
  score: number;
  issues: QualityIssue[];
  nullTotal: number;
  dupTotal: number;
}

export interface KPI {
  label: string;
  value: string;
  delta?: string;
  direction?: 'up' | 'down' | 'flat';
  insight?: string;
}

export interface CleanOperation {
  action: string;
  column?: string;
  description?: string;
  method?: string;
  value?: string;
  newName?: string;
  oldValue?: string;
  newValue?: string;
  targetType?: string;
}

export interface LogEntry {
  id: number;
  text: string;
  timestamp: string;
  type: 'etl' | 'error' | 'doc' | 'clean' | 'info';
}

export interface DictionaryEntry {
  column: string;
  businessDefinition: string;
  dataType: string;
  formatNotes: string;
  qualityStatus: 'Good' | 'Warning' | 'Critical';
  qualityNote: string;
  example: string;
}

export type TabName = 'Overview' | 'Data Source' | 'Data Quality' | 'Transformation' | 'Analytics' | 'Documentation';
