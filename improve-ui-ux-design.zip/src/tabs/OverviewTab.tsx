import { useApp } from '../store';
import { KPICard } from '../components/KPICard';
import { Badge } from '../components/Badge';
import {
  Database, Shield, Sparkles, BarChart3, FileText,
  Rows3, AlertTriangle, CheckCircle2,
  ArrowRight, Zap
} from 'lucide-react';
import { cn } from '@/utils/cn';

export function OverviewTab() {
  const { state, dispatch } = useApp();
  const { data, quality, cleanLog } = state;
  const hasData = data !== null;

  const steps = [
    { label: 'Load', icon: Database, done: hasData },
    { label: 'Quality', icon: Shield, done: quality !== null },
    { label: 'Clean', icon: Sparkles, done: cleanLog.length > 0 },
    { label: 'Transform', icon: Zap, done: cleanLog.some(l => l.text.includes('[ETL]')) },
    { label: 'Report', icon: BarChart3, done: state.execReport !== null },
    { label: 'Docs', icon: FileText, done: state.dictionary !== null },
  ];

  if (!hasData) {
    return (
      <div className="animate-fade-in">
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-slate-900 tracking-tight">Welcome to DataOps AI</h2>
          <p className="text-sm text-slate-500 mt-1">Your intelligent data pipeline — load, clean, analyze, and document.</p>
        </div>

        {/* Hero empty state */}
        <div className="relative border border-dashed border-slate-300 rounded-2xl p-12 text-center bg-gradient-to-b from-slate-50/80 to-white overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_-20%,rgba(59,130,246,0.05),transparent_70%)]" />
          <div className="relative">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-100 flex items-center justify-center mx-auto mb-5">
              <Database className="w-9 h-9 text-blue-500" />
            </div>
            <h3 className="text-base font-semibold text-slate-700 mb-2">No dataset loaded</h3>
            <p className="text-sm text-slate-400 max-w-sm mx-auto mb-6">
              Upload a CSV or Excel file, connect to a SQL database, or load sample data to get started.
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => dispatch({ type: 'SET_TAB', tab: 'Data Source' })}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm shadow-blue-200"
              >
                Load Data
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Pipeline steps preview */}
        <div className="mt-10">
          <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-4">Pipeline Steps</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.label}
                  className="flex flex-col items-center p-4 rounded-xl border border-slate-200 bg-white text-center opacity-60"
                >
                  <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center mb-2 text-slate-300">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-medium text-slate-400">
                    {i + 1}. {step.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  const columns = Object.keys(data[0] || {});
  const issueCount = quality?.issues.length ?? 0;
  const scoreValue = quality?.score ?? null;

  return (
    <div className="animate-fade-in space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 tracking-tight">Pipeline Overview</h2>
        <p className="text-sm text-slate-500 mt-1">Current state of your data pipeline.</p>
      </div>

      {/* Pipeline progress */}
      <div className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex items-center justify-between gap-2">
          {steps.map((step, i) => {
            const Icon = step.icon;
            return (
              <div key={step.label} className="flex items-center flex-1 last:flex-none">
                <div className="flex flex-col items-center">
                  <div
                    className={cn(
                      'w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300',
                      step.done
                        ? 'bg-emerald-500 text-white shadow-sm shadow-emerald-200'
                        : 'bg-slate-100 text-slate-400'
                    )}
                  >
                    {step.done ? (
                      <CheckCircle2 className="w-5 h-5" />
                    ) : (
                      <Icon className="w-5 h-5" />
                    )}
                  </div>
                  <span
                    className={cn(
                      'text-[11px] font-medium mt-2',
                      step.done ? 'text-emerald-600' : 'text-slate-400'
                    )}
                  >
                    {step.label}
                  </span>
                </div>
                {i < steps.length - 1 && (
                  <div className="flex-1 mx-2 mb-5">
                    <div
                      className={cn(
                        'h-[2px] w-full rounded-full transition-colors duration-300',
                        step.done ? 'bg-emerald-300' : 'bg-slate-200'
                      )}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          label="Rows"
          value={data.length.toLocaleString()}
          subtitle={`${columns.length} columns`}
          icon={<Rows3 className="w-4 h-4" />}
          accentColor="#3b82f6"
        />
        <KPICard
          label="Quality Score"
          value={scoreValue !== null ? String(scoreValue) : '—'}
          subtitle={scoreValue !== null ? 'out of 100' : 'Run analysis'}
          icon={<Shield className="w-4 h-4" />}
          accentColor={scoreValue !== null ? (scoreValue >= 80 ? '#059669' : scoreValue >= 60 ? '#d97706' : '#dc2626') : '#94a3b8'}
        />
        <KPICard
          label="Issues Found"
          value={quality ? String(issueCount) : '—'}
          subtitle="quality checks"
          icon={<AlertTriangle className="w-4 h-4" />}
          accentColor="#f59e0b"
        />
        <KPICard
          label="Operations"
          value={String(cleanLog.length)}
          subtitle="applied so far"
          icon={<Sparkles className="w-4 h-4" />}
          accentColor="#8b5cf6"
        />
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'Data Source', icon: Database, tab: 'Data Source' as const, desc: 'Manage data sources' },
            { label: 'Quality Analysis', icon: Shield, tab: 'Data Quality' as const, desc: 'Profile & diagnose' },
            { label: 'Transformations', icon: Zap, tab: 'Transformation' as const, desc: 'Reshape data' },
            { label: 'Analytics', icon: BarChart3, tab: 'Analytics' as const, desc: 'Explore & visualize' },
          ].map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                onClick={() => dispatch({ type: 'SET_TAB', tab: item.tab })}
                className="flex items-center gap-3 p-3.5 bg-white border border-slate-200 rounded-xl hover:border-blue-300 hover:bg-blue-50/30 transition-all text-left group"
              >
                <div className="p-2 rounded-lg bg-slate-50 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-colors">
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-medium text-slate-700 group-hover:text-blue-700">{item.label}</div>
                  <div className="text-[11px] text-slate-400">{item.desc}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Column Overview */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-3">Column Overview</h3>
        <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50/80">
                <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-400 border-b border-slate-200">Column</th>
                <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-400 border-b border-slate-200">Type</th>
                <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-400 border-b border-slate-200">Non-null</th>
                <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-400 border-b border-slate-200">Null %</th>
                <th className="text-left px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em] text-slate-400 border-b border-slate-200">Unique</th>
              </tr>
            </thead>
            <tbody>
              {columns.map(col => {
                const nullCount = data.filter(r => r[col] === null || r[col] === undefined || r[col] === '').length;
                const nullPct = Math.round((nullCount / data.length) * 1000) / 10;
                const uniqueCount = new Set(data.map(r => String(r[col]))).size;
                const isNumeric = data.some(r => typeof r[col] === 'number');

                return (
                  <tr key={col} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition-colors">
                    <td className="px-4 py-2.5 font-mono text-[13px] font-medium text-slate-800">{col}</td>
                    <td className="px-4 py-2.5">
                      <Badge variant={isNumeric ? 'info' : 'neutral'}>
                        {isNumeric ? 'number' : 'string'}
                      </Badge>
                    </td>
                    <td className="px-4 py-2.5 text-[13px] text-slate-600 font-mono">{(data.length - nullCount).toLocaleString()}</td>
                    <td className="px-4 py-2.5">
                      {nullPct > 0 ? (
                        <span className={cn('text-[13px] font-mono', nullPct > 20 ? 'text-red-600' : nullPct > 0 ? 'text-amber-600' : 'text-slate-500')}>
                          {nullPct}%
                        </span>
                      ) : (
                        <span className="text-[13px] text-slate-300 font-mono">0%</span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-[13px] text-slate-600 font-mono">{uniqueCount.toLocaleString()}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
