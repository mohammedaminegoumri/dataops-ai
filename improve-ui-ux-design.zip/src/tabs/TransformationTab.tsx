import { useState } from 'react';
import { useApp } from '../store';
import { EmptyState } from '../components/EmptyState';
import { DataTable } from '../components/DataTable';
import { applyOperation } from '../utils/dataEngine';
import {
  Zap, Columns3, ArrowUpDown, Play
} from 'lucide-react';
import { cn } from '@/utils/cn';
import type { DataRow } from '../types';

export function TransformationTab() {
  const { state, dispatch } = useApp();
  const { data } = state;
  const [activePanel, setActivePanel] = useState<'columns' | 'sort' | 'filter' | 'aggregate'>('columns');
  
  // Column ops
  const [colAction, setColAction] = useState('rename_column');
  const [sourceCol, setSourceCol] = useState('');
  const [newColName, setNewColName] = useState('');
  const [replaceOld, setReplaceOld] = useState('');
  const [replaceNew, setReplaceNew] = useState('');

  // Sort
  const [sortCol, setSortCol] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  // Filter
  const [filterCol, setFilterCol] = useState('');
  const [filterOp, setFilterOp] = useState('equals');
  const [filterVal, setFilterVal] = useState('');

  // Aggregate
  const [groupCol, setGroupCol] = useState('');
  const [aggCol, setAggCol] = useState('');
  const [aggFunc, setAggFunc] = useState('sum');

  if (!data) {
    return (
      <EmptyState
        icon={<Zap className="w-7 h-7" />}
        title="No dataset loaded"
        description="Load data in the Data Source tab first."
      />
    );
  }

  const columns = Object.keys(data[0]);
  const numCols = columns.filter(c => data.some(r => typeof r[c] === 'number'));

  const applyColumnOp = () => {
    if (colAction === 'rename_column' && sourceCol && newColName) {
      const result = applyOperation(data, 'rename_column', sourceCol, { newName: newColName });
      dispatch({ type: 'UPDATE_DATA', data: result.data });
      dispatch({ type: 'ADD_LOG', entry: { text: `[ETL] ${result.log}`, type: 'etl' } });
    } else if (colAction === 'drop_column' && sourceCol) {
      const result = applyOperation(data, 'drop_column', sourceCol);
      dispatch({ type: 'UPDATE_DATA', data: result.data });
      dispatch({ type: 'ADD_LOG', entry: { text: `[ETL] ${result.log}`, type: 'etl' } });
    } else if (colAction === 'replace_value' && sourceCol) {
      const result = applyOperation(data, 'replace_value', sourceCol, { oldValue: replaceOld, newValue: replaceNew });
      dispatch({ type: 'UPDATE_DATA', data: result.data });
      dispatch({ type: 'ADD_LOG', entry: { text: `[ETL] ${result.log}`, type: 'etl' } });
    } else if (colAction === 'uppercase' && sourceCol) {
      const result = applyOperation(data, 'uppercase', sourceCol);
      dispatch({ type: 'UPDATE_DATA', data: result.data });
      dispatch({ type: 'ADD_LOG', entry: { text: `[ETL] ${result.log}`, type: 'etl' } });
    } else if (colAction === 'lowercase' && sourceCol) {
      const result = applyOperation(data, 'lowercase', sourceCol);
      dispatch({ type: 'UPDATE_DATA', data: result.data });
      dispatch({ type: 'ADD_LOG', entry: { text: `[ETL] ${result.log}`, type: 'etl' } });
    }
  };

  const applySort = () => {
    if (!sortCol) return;
    const sorted = [...data].sort((a, b) => {
      const va = a[sortCol], vb = b[sortCol];
      if (va === null || va === undefined) return 1;
      if (vb === null || vb === undefined) return -1;
      const cmp = typeof va === 'number' && typeof vb === 'number' ? va - vb : String(va).localeCompare(String(vb));
      return sortDir === 'asc' ? cmp : -cmp;
    });
    dispatch({ type: 'UPDATE_DATA', data: sorted });
    dispatch({ type: 'ADD_LOG', entry: { text: `[ETL] Sorted by ${sortCol} (${sortDir})`, type: 'etl' } });
  };

  const applyFilter = () => {
    if (!filterCol) return;
    const filtered = data.filter(r => {
      const v = r[filterCol];
      const sv = String(v);
      const numV = Number(v);
      switch (filterOp) {
        case 'equals': return sv === filterVal;
        case 'not_equals': return sv !== filterVal;
        case 'contains': return sv.toLowerCase().includes(filterVal.toLowerCase());
        case 'greater_than': return !isNaN(numV) && numV > Number(filterVal);
        case 'less_than': return !isNaN(numV) && numV < Number(filterVal);
        case 'not_null': return v !== null && v !== undefined && v !== '';
        case 'is_null': return v === null || v === undefined || v === '';
        default: return true;
      }
    });
    dispatch({ type: 'UPDATE_DATA', data: filtered });
    dispatch({ type: 'ADD_LOG', entry: { text: `[ETL] Filtered ${filterCol} ${filterOp} "${filterVal}" → ${filtered.length} rows`, type: 'etl' } });
  };

  const applyAggregate = () => {
    if (!groupCol || !aggCol) return;
    const groups: Record<string, number[]> = {};
    for (const row of data) {
      const key = String(row[groupCol] ?? '(null)');
      if (!groups[key]) groups[key] = [];
      const n = Number(row[aggCol]);
      if (!isNaN(n)) groups[key].push(n);
    }
    const result: DataRow[] = Object.entries(groups).map(([key, vals]) => {
      let value: number;
      switch (aggFunc) {
        case 'sum': value = vals.reduce((a, b) => a + b, 0); break;
        case 'mean': value = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0; break;
        case 'count': value = vals.length; break;
        case 'min': value = Math.min(...vals); break;
        case 'max': value = Math.max(...vals); break;
        default: value = 0;
      }
      return { [groupCol]: key, [`${aggFunc}_${aggCol}`]: Math.round(value * 100) / 100 };
    });
    dispatch({ type: 'UPDATE_DATA', data: result });
    dispatch({ type: 'ADD_LOG', entry: { text: `[ETL] Aggregated ${aggFunc}(${aggCol}) by ${groupCol} → ${result.length} rows`, type: 'etl' } });
  };

  const panels = [
    { key: 'columns' as const, label: 'Column Ops', icon: Columns3 },
    { key: 'sort' as const, label: 'Sort', icon: ArrowUpDown },
    { key: 'filter' as const, label: 'Filter', icon: Zap },
    { key: 'aggregate' as const, label: 'Aggregate', icon: Play },
  ];

  return (
    <div className="animate-fade-in space-y-8">
      <div>
        <h2 className="text-lg font-semibold text-slate-900 tracking-tight">Transformation</h2>
        <p className="text-sm text-slate-500 mt-1">Reshape, sort, filter and aggregate your data.</p>
      </div>

      {/* Panel tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit">
        {panels.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActivePanel(tab.key)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                activePanel === tab.key
                  ? 'bg-white text-slate-800 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              )}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Column operations */}
      {activePanel === 'columns' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Operation</label>
              <select value={colAction} onChange={e => setColAction(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                <option value="rename_column">Rename column</option>
                <option value="drop_column">Drop column</option>
                <option value="replace_value">Replace value</option>
                <option value="uppercase">Uppercase</option>
                <option value="lowercase">Lowercase</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Source Column</label>
              <select value={sourceCol} onChange={e => setSourceCol(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                <option value="">Select...</option>
                {columns.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>
          {colAction === 'rename_column' && (
            <div className="mb-4">
              <label className="block text-xs font-medium text-slate-500 mb-1.5">New Name</label>
              <input value={newColName} onChange={e => setNewColName(e.target.value)} placeholder="New column name"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none" />
            </div>
          )}
          {colAction === 'replace_value' && (
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">Old Value</label>
                <input value={replaceOld} onChange={e => setReplaceOld(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">New Value</label>
                <input value={replaceNew} onChange={e => setReplaceNew(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none" />
              </div>
            </div>
          )}
          <button onClick={applyColumnOp}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
            <Play className="w-4 h-4" /> Apply
          </button>
        </div>
      )}

      {/* Sort */}
      {activePanel === 'sort' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Sort Column</label>
              <select value={sortCol} onChange={e => setSortCol(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                <option value="">Select...</option>
                {columns.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Direction</label>
              <select value={sortDir} onChange={e => setSortDir(e.target.value as 'asc' | 'desc')}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                <option value="asc">Ascending</option>
                <option value="desc">Descending</option>
              </select>
            </div>
          </div>
          <button onClick={applySort}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
            <ArrowUpDown className="w-4 h-4" /> Sort
          </button>
        </div>
      )}

      {/* Filter */}
      {activePanel === 'filter' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Column</label>
              <select value={filterCol} onChange={e => setFilterCol(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                <option value="">Select...</option>
                {columns.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Operator</label>
              <select value={filterOp} onChange={e => setFilterOp(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                <option value="equals">Equals</option>
                <option value="not_equals">Not equals</option>
                <option value="contains">Contains</option>
                <option value="greater_than">Greater than</option>
                <option value="less_than">Less than</option>
                <option value="not_null">Not null</option>
                <option value="is_null">Is null</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Value</label>
              <input value={filterVal} onChange={e => setFilterVal(e.target.value)} placeholder="Filter value"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none" />
            </div>
          </div>
          <button onClick={applyFilter}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
            <Zap className="w-4 h-4" /> Apply Filter
          </button>
        </div>
      )}

      {/* Aggregate */}
      {activePanel === 'aggregate' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Group By</label>
              <select value={groupCol} onChange={e => setGroupCol(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                <option value="">Select...</option>
                {columns.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Aggregate Column</label>
              <select value={aggCol} onChange={e => setAggCol(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                <option value="">Select...</option>
                {numCols.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Function</label>
              <select value={aggFunc} onChange={e => setAggFunc(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none">
                {['sum', 'mean', 'count', 'min', 'max'].map(f => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </div>
          </div>
          <button onClick={applyAggregate}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
            <Play className="w-4 h-4" /> Aggregate
          </button>
        </div>
      )}

      {/* Preview */}
      <div className="border-t border-slate-200 pt-8">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            Current Data — {data.length.toLocaleString()} rows × {columns.length} columns
          </h3>
        </div>
        <DataTable data={data} maxRows={20} compact />
      </div>
    </div>
  );
}
