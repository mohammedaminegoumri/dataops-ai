import { useState } from 'react';
import { useApp } from '../store';
import { KPICard } from '../components/KPICard';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';
import {
  Shield, AlertTriangle, XCircle, Info,
  Sparkles, Play, RotateCcw, Download
} from 'lucide-react';
import { runQualityAnalysis, applyOperation } from '../utils/dataEngine';
import { cn } from '@/utils/cn';

export function DataQualityTab() {
  const { state, dispatch } = useApp();
  const { data, quality, cleanLog } = state;
  const [manualAction, setManualAction] = useState('fill_nulls');
  const [manualColumn, setManualColumn] = useState('');
  const [manualMethod, setManualMethod] = useState('mean');
  const [manualValue, setManualValue] = useState('');
  const [activePanel, setActivePanel] = useState<'suggestions' | 'manual'>('suggestions');

  if (!data) {
    return (
      <EmptyState
        icon={<Shield className="w-7 h-7" />}
        title="No dataset loaded"
        description="Load data in the Data Source tab first."
      />
    );
  }

  const columns = Object.keys(data[0]);

  const runAnalysis = () => {
    const q = runQualityAnalysis(data);
    dispatch({ type: 'SET_QUALITY', quality: q });

    // Generate AI-like suggestions based on issues
    const suggestions = q.issues
      .filter(i => i.severity !== 'info')
      .map(issue => {
        if (issue.type === 'Missing values') {
          return { action: 'fill_nulls', column: issue.column, description: `Fill missing values in ${issue.column}`, method: 'mean' };
        }
        if (issue.type === 'Duplicate rows') {
          return { action: 'drop_duplicates', column: undefined, description: 'Remove duplicate rows' };
        }
        if (issue.type === 'Type mismatch') {
          return { action: 'convert_type', column: issue.column, description: `Convert ${issue.column} to numeric`, targetType: 'number' };
        }
        if (issue.type === 'Whitespace') {
          return { action: 'trim_whitespace', column: issue.column, description: `Trim whitespace in ${issue.column}` };
        }
        return null;
      })
      .filter(Boolean);

    dispatch({ type: 'SET_AI_SUGGESTIONS', suggestions });
  };

  const applySuggestion = (suggestion: any) => {
    const result = applyOperation(data, suggestion.action, suggestion.column, {
      method: suggestion.method || '',
      targetType: suggestion.targetType || '',
    });
    dispatch({ type: 'UPDATE_DATA', data: result.data });
    dispatch({ type: 'ADD_LOG', entry: { text: result.log, type: 'clean' } });
  };

  const applyManual = () => {
    const result = applyOperation(data, manualAction, manualColumn || undefined, {
      method: manualMethod,
      value: manualValue,
    });
    dispatch({ type: 'UPDATE_DATA', data: result.data });
    dispatch({ type: 'ADD_LOG', entry: { text: result.log, type: 'clean' } });
  };

  const resetData = () => {
    dispatch({ type: 'RESET_DATA' });
  };

  const severityIcon = (sev: string) => {
    if (sev === 'error') return <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />;
    if (sev === 'warning') return <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />;
    return <Info className="w-4 h-4 text-blue-500 flex-shrink-0" />;
  };

  const score = quality?.score;
  const scoreColor = score !== undefined ? (score >= 80 ? '#059669' : score >= 60 ? '#d97706' : '#dc2626') : undefined;
  const scoreLabel = score !== undefined ? (score >= 80 ? 'Good' : score >= 60 ? 'Fair' : 'Poor') : undefined;
  const scoreBadgeVal: 'success' | 'warning' | 'danger' | undefined = score !== undefined ? (score >= 80 ? 'success' : score >= 60 ? 'warning' : 'danger') : undefined;

  return (
    <div className="animate-fade-in space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 tracking-tight">Data Quality</h2>
          <p className="text-sm text-slate-500 mt-1">Automated profiling and diagnosis of your dataset.</p>
        </div>
        <div className="flex gap-2">
          {quality ? (
            <button
              onClick={() => { dispatch({ type: 'RESET_QUALITY' }); runAnalysis(); }}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              Re-run
            </button>
          ) : (
            <button
              onClick={runAnalysis}
              className="inline-flex items-center gap-2 px-5 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
            >
              <Play className="w-4 h-4" />
              Run Quality Analysis
            </button>
          )}
        </div>
      </div>

      {!quality && (
        <div className="border border-dashed border-slate-300 rounded-2xl p-12 text-center bg-slate-50/50">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center mx-auto mb-4">
            <Shield className="w-7 h-7 text-blue-500" />
          </div>
          <h3 className="text-sm font-semibold text-slate-600 mb-1">Ready to analyze</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Click "Run Quality Analysis" to profile your dataset, detect issues, and get cleaning recommendations.
          </p>
        </div>
      )}

      {quality && (
        <>
          {/* Score cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-5 relative overflow-hidden">
              {scoreColor && <div className="absolute top-0 left-0 w-full h-0.5" style={{ background: scoreColor }} />}
              <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-400 mb-2">Quality Score</div>
              <div className="flex items-baseline gap-1">
                <span className="font-mono text-4xl font-bold tracking-tight" style={{ color: scoreColor }}>
                  {score}
                </span>
                <span className="font-mono text-lg text-slate-300">/ 100</span>
              </div>
              {scoreBadgeVal && <div className="mt-2"><Badge variant={scoreBadgeVal}>{scoreLabel}</Badge></div>}
            </div>
            <KPICard
              label="Missing Values"
              value={quality.nullTotal.toLocaleString()}
              subtitle="across all columns"
              icon={<AlertTriangle className="w-4 h-4" />}
            />
            <KPICard
              label="Duplicate Rows"
              value={quality.dupTotal.toLocaleString()}
              subtitle="exact matches"
              icon={<XCircle className="w-4 h-4" />}
            />
            <KPICard
              label="Checks Flagged"
              value={String(quality.issues.length)}
              subtitle="total issues"
              icon={<Info className="w-4 h-4" />}
            />
          </div>

          {/* Issues */}
          {quality.issues.length > 0 && (
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-3">Issues Detected</h3>
              <div className="space-y-2">
                {quality.issues.map((issue, i) => (
                  <div
                    key={i}
                    className={cn(
                      'flex items-start gap-3 p-3.5 rounded-xl border transition-colors',
                      issue.severity === 'error' && 'bg-red-50/80 border-red-200',
                      issue.severity === 'warning' && 'bg-amber-50/80 border-amber-200',
                      issue.severity === 'info' && 'bg-blue-50/80 border-blue-200'
                    )}
                  >
                    {severityIcon(issue.severity)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-semibold text-slate-800">{issue.column}</span>
                        <Badge variant={issue.severity === 'error' ? 'danger' : issue.severity === 'warning' ? 'warning' : 'info'}>
                          {issue.type}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{issue.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cleaning operations */}
          <div className="border-t border-slate-200 pt-8">
            <div className="mb-4">
              <h3 className="text-sm font-semibold text-slate-800">Cleaning Operations</h3>
              <p className="text-xs text-slate-500 mt-0.5">Apply fixes to your dataset. All changes are logged.</p>
            </div>

            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit mb-6">
              {[
                { key: 'suggestions' as const, label: 'AI Suggestions', icon: Sparkles },
                { key: 'manual' as const, label: 'Manual Operations', icon: Play },
              ].map(tab => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.key}
                    onClick={() => setActivePanel(tab.key)}
                    className={cn(
                      'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                      activePanel === tab.key
                        ? 'bg-white text-slate-800 shadow-sm'
                        : 'text-slate-500 hover:text-slate-700'
                    )}
                  >
                    <Icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {activePanel === 'suggestions' && (
              <div className="space-y-2">
                {state.aiSuggestions.length > 0 ? (
                  state.aiSuggestions.map((s: any, i: number) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl hover:border-blue-200 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-1.5 rounded-lg bg-violet-50 text-violet-500">
                          <Sparkles className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-slate-700">{s.description}</div>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                            {s.action} {s.column ? `→ ${s.column}` : ''}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => applySuggestion(s)}
                        className="px-3 py-1.5 text-xs font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                      >
                        Apply
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="p-6 text-center text-sm text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                    Run quality analysis to receive suggestions.
                  </div>
                )}
              </div>
            )}

            {activePanel === 'manual' && (
              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">Operation</label>
                    <select
                      value={manualAction}
                      onChange={e => setManualAction(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all"
                    >
                      {['fill_nulls', 'drop_nulls', 'drop_duplicates', 'trim_whitespace', 'convert_type', 'drop_column', 'cap_outliers', 'uppercase', 'lowercase'].map(a => (
                        <option key={a} value={a}>{a.replace(/_/g, ' ')}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">Target Column</label>
                    <select
                      value={manualColumn}
                      onChange={e => setManualColumn(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all"
                    >
                      <option value="">(all)</option>
                      {columns.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">Fill Method</label>
                    <select
                      value={manualMethod}
                      onChange={e => setManualMethod(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all"
                    >
                      {['mean', 'median', 'mode', 'value'].map(m => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">Constant Value</label>
                    <input
                      value={manualValue}
                      onChange={e => setManualValue(e.target.value)}
                      placeholder="e.g. 0 or N/A"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all"
                    />
                  </div>
                </div>
                <button
                  onClick={applyManual}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Play className="w-4 h-4" />
                  Apply Operation
                </button>
              </div>
            )}
          </div>

          {/* Operation log */}
          {cleanLog.length > 0 && (
            <div className="border-t border-slate-200 pt-8">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400">Operation Log</h3>
                <button
                  onClick={resetData}
                  className="text-xs text-slate-400 hover:text-red-500 transition-colors"
                >
                  Reset to original
                </button>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                {cleanLog.map((entry, i) => (
                  <div
                    key={entry.id}
                    className="flex items-center gap-4 px-4 py-2.5 border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition-colors"
                  >
                    <span className="text-[11px] text-slate-300 font-mono w-6">{String(i + 1).padStart(2, '0')}</span>
                    <span className={cn(
                      'flex-1 text-xs',
                      entry.type === 'error' ? 'text-red-600' : entry.type === 'etl' ? 'text-blue-600' : 'text-slate-600'
                    )}>
                      {entry.text}
                    </span>
                    <span className="text-[10px] text-slate-300 font-mono">{entry.timestamp}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Export */}
          <div className="border-t border-slate-200 pt-8">
            <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400 mb-3">Export</h3>
            <div className="flex gap-3">
              <button
                onClick={() => {
                  const header = columns.join(',');
                  const rows = data.map(r => columns.map(c => JSON.stringify(r[c] ?? '')).join(','));
                  const csv = [header, ...rows].join('\n');
                  const blob = new Blob([csv], { type: 'text/csv' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url; a.download = `cleaned_${state.filename || 'data'}.csv`; a.click();
                  URL.revokeObjectURL(url);
                }}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
              >
                <Download className="w-4 h-4" />
                Download CSV
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
