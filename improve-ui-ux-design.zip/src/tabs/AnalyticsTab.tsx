import { useState, useMemo } from 'react';
import { useApp } from '../store';
import { EmptyState } from '../components/EmptyState';
import { KPICard } from '../components/KPICard';
import {
  BarChart3, TrendingUp, PieChart, Activity
} from 'lucide-react';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  ScatterChart, Scatter, PieChart as RePieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { getBasicStats, getValueCounts, getCorrelationMatrix } from '../utils/dataEngine';
import { cn } from '@/utils/cn';

const COLORS = ['#3b82f6', '#8b5cf6', '#059669', '#d97706', '#dc2626', '#0891b2', '#7c3aed', '#0d9488'];

export function AnalyticsTab() {
  const { state } = useApp();
  const { data } = state;
  const [activePanel, setActivePanel] = useState<'overview' | 'charts' | 'stats' | 'correlation'>('overview');
  const [chartType, setChartType] = useState<'bar' | 'line' | 'area' | 'scatter' | 'pie'>('bar');
  const [chartX, setChartX] = useState('');
  const [chartY, setChartY] = useState('');
  const [statsCol, setStatsCol] = useState('');
  const [vcCol, setVcCol] = useState('');

  const columns = useMemo(() => data ? Object.keys(data[0] || {}) : [], [data]);
  const numCols = useMemo(() => data ? columns.filter(c => data.some(r => typeof r[c] === 'number')) : [], [data, columns]);
  const catCols = useMemo(() => data ? columns.filter(c => !numCols.includes(c)) : [], [columns, numCols, data]);

  if (!data) {
    return (
      <EmptyState
        icon={<BarChart3 className="w-7 h-7" />}
        title="No dataset loaded"
        description="Load data in the Data Source tab first."
      />
    );
  }

  // Auto KPIs
  const autoKPIs = useMemo(() => {
    const kpis: { label: string; value: string; subtitle: string; direction: 'up' | 'down' | 'flat' }[] = [];
    kpis.push({ label: 'Total Rows', value: data.length.toLocaleString(), subtitle: `${columns.length} columns`, direction: 'flat' });

    for (const col of numCols.slice(0, 3)) {
      const stats = getBasicStats(data, col);
      if (stats) {
        kpis.push({
          label: `Avg ${col}`,
          value: stats.mean.toLocaleString(),
          subtitle: `Range: ${stats.min.toLocaleString()} – ${stats.max.toLocaleString()}`,
          direction: 'flat',
        });
      }
    }
    return kpis;
  }, [data, columns, numCols]);

  // Chart data
  const chartData = useMemo((): { name: string; value: number }[] => {
    if (!chartX) return [];
    if (chartType === 'pie') {
      return getValueCounts(data, chartX, 8).map(v => ({ name: v.value, value: v.count }));
    }
    if (chartX && chartY) {
      const groups: Record<string, number[]> = {};
      for (const row of data) {
        const key = String(row[chartX] ?? '');
        if (!groups[key]) groups[key] = [];
        const n = Number(row[chartY]);
        if (!isNaN(n)) groups[key].push(n);
      }
      return Object.entries(groups).map(([key, vals]) => ({
        name: key,
        value: Math.round(vals.reduce((a, b) => a + b, 0) * 100) / 100,
      }));
    }
    return [];
  }, [data, chartX, chartY, chartType]);

  const panels = [
    { key: 'overview' as const, label: 'Overview', icon: TrendingUp },
    { key: 'charts' as const, label: 'Charts', icon: BarChart3 },
    { key: 'stats' as const, label: 'Statistics', icon: Activity },
    { key: 'correlation' as const, label: 'Correlation', icon: PieChart },
  ];

  const renderChart = () => {
    if (chartData.length === 0) return null;
    
    const commonProps = { data: chartData };
    
    if (chartType === 'pie') {
      return (
        <ResponsiveContainer width="100%" height={350}>
          <RePieChart>
            <Pie
              data={chartData}
              dataKey="count"
              nameKey="value"
              cx="50%"
              cy="50%"
              outerRadius={120}
              innerRadius={60}
              paddingAngle={2}
              label
            >
              {chartData.map((_: unknown, i: number) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </RePieChart>
        </ResponsiveContainer>
      );
    }

    if (chartType === 'scatter') {
      return (
        <ResponsiveContainer width="100%" height={350}>
          <ScatterChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
            <Tooltip />
            <Scatter dataKey="value" fill={COLORS[0]} />
          </ScatterChart>
        </ResponsiveContainer>
      );
    }

    if (chartType === 'line') {
      return (
        <ResponsiveContainer width="100%" height={350}>
          <LineChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
            <Tooltip
              contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.07)' }}
            />
            <Line type="monotone" dataKey="value" stroke={COLORS[0]} strokeWidth={2} dot={{ r: 3, fill: COLORS[0] }} />
          </LineChart>
        </ResponsiveContainer>
      );
    }

    if (chartType === 'area') {
      return (
        <ResponsiveContainer width="100%" height={350}>
          <AreaChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
            <Tooltip
              contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.07)' }}
            />
            <Area type="monotone" dataKey="value" stroke={COLORS[0]} fill={`${COLORS[0]}20`} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      );
    }

    // Default: bar
    return (
      <ResponsiveContainer width="100%" height={350}>
        <BarChart {...commonProps}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
          <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
          <Tooltip
            contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.07)' }}
          />
          <Bar dataKey="value" fill={COLORS[0]} radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    );
  };

  const corrData = useMemo(() => {
    if (numCols.length < 2) return null;
    return getCorrelationMatrix(data, numCols.slice(0, 8));
  }, [data, numCols]);

  return (
    <div className="animate-fade-in space-y-8">
      <div>
        <h2 className="text-lg font-semibold text-slate-900 tracking-tight">Analytics</h2>
        <p className="text-sm text-slate-500 mt-1">Explore your data through interactive visualizations.</p>
      </div>

      {/* Panel tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit">
        {panels.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActivePanel(tab.key)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                activePanel === tab.key
                  ? 'bg-white text-slate-800 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              )}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Overview */}
      {activePanel === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {autoKPIs.map((kpi, i) => (
              <KPICard key={i} label={kpi.label} value={kpi.value} subtitle={kpi.subtitle} direction={kpi.direction} />
            ))}
          </div>

          {/* Auto charts */}
          {catCols.length > 0 && numCols.length > 0 && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {catCols.slice(0, 2).map(cat => {
                const vc = getValueCounts(data, cat, 8);
                return (
                  <div key={cat} className="bg-white border border-slate-200 rounded-xl p-5">
                    <h4 className="text-sm font-semibold text-slate-700 mb-4">{cat} — Distribution</h4>
                    <ResponsiveContainer width="100%" height={250}>
                      <BarChart data={vc}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                        <XAxis dataKey="value" tick={{ fontSize: 10, fill: '#64748b' }} />
                        <YAxis tick={{ fontSize: 10, fill: '#64748b' }} />
                        <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0' }} />
                        <Bar dataKey="count" fill={COLORS[0]} radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Custom Charts */}
      {activePanel === 'charts' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">Chart Type</label>
                <select value={chartType} onChange={e => setChartType(e.target.value as typeof chartType)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 outline-none">
                  {['bar', 'line', 'area', 'scatter', 'pie'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">X Axis / Category</label>
                <select value={chartX} onChange={e => setChartX(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 outline-none">
                  <option value="">Select...</option>
                  {columns.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">Y Axis / Value</label>
                <select value={chartY} onChange={e => setChartY(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 outline-none">
                  <option value="">Select...</option>
                  {numCols.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            {chartData.length > 0 ? renderChart() : (
              <div className="h-[350px] flex items-center justify-center text-sm text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                Select X and Y columns to generate a chart
              </div>
            )}
          </div>
        </div>
      )}

      {/* Statistics */}
      {activePanel === 'stats' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Numeric stats */}
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <h4 className="text-sm font-semibold text-slate-700 mb-4">Column Statistics</h4>
              <div className="mb-3">
                <select value={statsCol} onChange={e => setStatsCol(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 outline-none">
                  <option value="">Select column...</option>
                  {numCols.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              {statsCol && (() => {
                const stats = getBasicStats(data, statsCol);
                if (!stats) return <p className="text-sm text-slate-400">No numeric data.</p>;
                return (
                  <div className="space-y-2">
                    {Object.entries(stats).map(([k, v]) => (
                      <div key={k} className="flex items-center justify-between py-1.5 border-b border-slate-100 last:border-0">
                        <span className="text-xs uppercase tracking-wide text-slate-400 font-medium">{k}</span>
                        <span className="font-mono text-sm text-slate-700">{Number(v).toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </div>

            {/* Value counts */}
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <h4 className="text-sm font-semibold text-slate-700 mb-4">Value Counts</h4>
              <div className="mb-3">
                <select value={vcCol} onChange={e => setVcCol(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:border-blue-400 outline-none">
                  <option value="">Select column...</option>
                  {catCols.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              {vcCol && (() => {
                const vc = getValueCounts(data, vcCol, 15);
                const maxCount = Math.max(...vc.map(v => v.count));
                return (
                  <div className="space-y-1.5">
                    {vc.map((item, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <span className="text-xs text-slate-600 font-mono w-28 truncate">{item.value}</span>
                        <div className="flex-1 bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-blue-500"
                            style={{ width: `${(item.count / maxCount) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs font-mono text-slate-400 w-10 text-right">{item.count}</span>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* Correlation */}
      {activePanel === 'correlation' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h4 className="text-sm font-semibold text-slate-700 mb-4">Correlation Matrix</h4>
          {corrData && corrData.cols.length >= 2 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="px-2 py-2 text-[10px] font-mono text-slate-400" />
                    {corrData.cols.map(c => (
                      <th key={c} className="px-2 py-2 text-[10px] font-mono text-slate-500 text-center" style={{ minWidth: 60 }}>
                        {c.length > 8 ? c.slice(0, 8) + '…' : c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {corrData.cols.map((row, ri) => (
                    <tr key={row}>
                      <td className="px-2 py-2 text-[10px] font-mono text-slate-500 text-right">{row.length > 10 ? row.slice(0, 10) + '…' : row}</td>
                      {corrData.matrix[ri].map((val, ci) => {
                        const absVal = Math.abs(val);
                        const bg = val > 0
                          ? `rgba(59, 130, 246, ${absVal * 0.6})`
                          : `rgba(220, 38, 38, ${absVal * 0.6})`;
                        return (
                          <td
                            key={ci}
                            className="px-2 py-2 text-center text-[11px] font-mono"
                            style={{
                              backgroundColor: ri === ci ? '#f8fafc' : bg,
                              color: absVal > 0.5 ? 'white' : '#334155',
                            }}
                          >
                            {val.toFixed(2)}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-slate-400 text-center py-8">
              At least 2 numeric columns are needed for a correlation matrix.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
