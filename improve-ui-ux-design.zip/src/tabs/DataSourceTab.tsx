import { useState, useCallback } from 'react';
import { useApp } from '../store';
import { DataTable } from '../components/DataTable';
import { Upload, Database, FileSpreadsheet, CheckCircle2, AlertCircle } from 'lucide-react';
import Papa from 'papaparse';
import type { DataRow } from '../types';
import { generateSampleData } from '../utils/sampleData';
import { getBasicStats } from '../utils/dataEngine';
import { cn } from '@/utils/cn';

export function DataSourceTab() {
  const { state, dispatch } = useApp();
  const [activeTab, setActiveTab] = useState<'file' | 'sample'>('file');
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleFile = useCallback((file: File) => {
    setError(null);
    setSuccess(null);

    if (!file.name.endsWith('.csv')) {
      setError('Please upload a CSV file.');
      return;
    }

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
      complete: (results) => {
        const data = results.data as DataRow[];
        if (data.length === 0) {
          setError('File is empty or could not be parsed.');
          return;
        }
        dispatch({ type: 'SET_DATA', data, filename: file.name });
        setSuccess(`Loaded ${file.name} — ${data.length.toLocaleString()} rows, ${Object.keys(data[0]).length} columns`);
      },
      error: (err) => {
        setError(`Parse error: ${err.message}`);
      },
    });
  }, [dispatch]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const loadSample = useCallback(() => {
    const data = generateSampleData(200);
    dispatch({ type: 'SET_DATA', data, filename: 'sample_sales_data.csv' });
    setSuccess(`Loaded sample dataset — ${data.length.toLocaleString()} rows, ${Object.keys(data[0]).length} columns`);
  }, [dispatch]);

  const { data, filename } = state;

  return (
    <div className="animate-fade-in space-y-8">
      <div>
        <h2 className="text-lg font-semibold text-slate-900 tracking-tight">Data Source</h2>
        <p className="text-sm text-slate-500 mt-1">Upload a file or load sample data to get started.</p>
      </div>

      {/* Source tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit">
        {[
          { key: 'file' as const, label: 'File Upload', icon: Upload },
          { key: 'sample' as const, label: 'Sample Data', icon: Database },
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                activeTab === tab.key
                  ? 'bg-white text-slate-800 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              )}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Alerts */}
      {error && (
        <div className="flex items-center gap-3 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 animate-fade-in">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}
      {success && (
        <div className="flex items-center gap-3 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-sm text-emerald-700 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          {success}
        </div>
      )}

      {/* File upload */}
      {activeTab === 'file' && (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className={cn(
            'relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-200 cursor-pointer group',
            dragOver
              ? 'border-blue-400 bg-blue-50/50'
              : 'border-slate-300 bg-slate-50/50 hover:border-blue-300 hover:bg-blue-50/30'
          )}
          onClick={() => document.getElementById('file-input')?.click()}
        >
          <input
            id="file-input"
            type="file"
            accept=".csv"
            className="hidden"
            onChange={handleInputChange}
          />
          <div className={cn(
            'w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 transition-colors',
            dragOver ? 'bg-blue-100 text-blue-500' : 'bg-slate-100 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500'
          )}>
            <FileSpreadsheet className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-semibold text-slate-600 mb-1">
            {dragOver ? 'Drop your file here' : 'Drop a CSV file here, or click to browse'}
          </h3>
          <p className="text-xs text-slate-400">Supports CSV format • Max 50MB</p>
        </div>
      )}

      {/* Sample data */}
      {activeTab === 'sample' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50 text-blue-500">
              <Database className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-slate-800 mb-1">Sample Sales Dataset</h3>
              <p className="text-xs text-slate-500 leading-relaxed mb-4">
                200+ rows of sales data with regions, products, revenue, costs, and customer ratings.
                Includes intentional data quality issues for testing.
              </p>
              <button
                onClick={loadSample}
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
              >
                Load Sample Data
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Data preview */}
      {data && (
        <>
          <div className="border-t border-slate-200 pt-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-800">Data Preview</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {filename} — {data.length.toLocaleString()} rows × {Object.keys(data[0]).length} columns
                </p>
              </div>
            </div>
            <DataTable data={data} maxRows={25} />
          </div>

          {/* Stats */}
          <div className="border-t border-slate-200 pt-8">
            <h3 className="text-sm font-semibold text-slate-800 mb-4">Statistical Summary</h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {Object.keys(data[0]).map(col => {
                const stats = getBasicStats(data, col);
                if (!stats) return null;
                return (
                  <div key={col} className="bg-white border border-slate-200 rounded-xl p-4">
                    <div className="font-mono text-xs font-semibold text-slate-700 mb-3 truncate">{col}</div>
                    <div className="space-y-1.5">
                      {(['mean', 'median', 'std', 'min', 'max'] as const).map(k => (
                        <div key={k} className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400 uppercase tracking-wide">{k}</span>
                          <span className="font-mono text-slate-600">{stats[k].toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
