import { createContext, useContext, useReducer, type ReactNode } from 'react';
import type { DataRow, QualityResult, KPI, LogEntry, DictionaryEntry, TabName } from './types';

interface AppState {
  tab: TabName;
  data: DataRow[] | null;
  originalData: DataRow[] | null;
  filename: string | null;
  cleanLog: LogEntry[];
  quality: QualityResult | null;
  aiDiagnosis: string | null;
  aiSuggestions: any[];
  kpis: KPI[];
  execReport: string | null;
  dictionary: DictionaryEntry[] | null;
  changelog: string | null;
  readme: string | null;
}

type Action =
  | { type: 'SET_TAB'; tab: TabName }
  | { type: 'SET_DATA'; data: DataRow[]; filename: string }
  | { type: 'UPDATE_DATA'; data: DataRow[] }
  | { type: 'SET_QUALITY'; quality: QualityResult }
  | { type: 'SET_AI_DIAGNOSIS'; diagnosis: string }
  | { type: 'SET_AI_SUGGESTIONS'; suggestions: any[] }
  | { type: 'ADD_LOG'; entry: Omit<LogEntry, 'id' | 'timestamp'> }
  | { type: 'SET_KPIS'; kpis: KPI[] }
  | { type: 'SET_EXEC_REPORT'; report: string }
  | { type: 'SET_DICTIONARY'; dictionary: DictionaryEntry[] }
  | { type: 'SET_CHANGELOG'; changelog: string }
  | { type: 'SET_README'; readme: string }
  | { type: 'RESET_DATA' }
  | { type: 'RESET_QUALITY' };

const initialState: AppState = {
  tab: 'Overview',
  data: null,
  originalData: null,
  filename: null,
  cleanLog: [],
  quality: null,
  aiDiagnosis: null,
  aiSuggestions: [],
  kpis: [],
  execReport: null,
  dictionary: null,
  changelog: null,
  readme: null,
};

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_TAB':
      return { ...state, tab: action.tab };
    case 'SET_DATA':
      return {
        ...initialState,
        tab: state.tab,
        data: action.data,
        originalData: [...action.data.map(r => ({ ...r }))],
        filename: action.filename,
      };
    case 'UPDATE_DATA':
      return { ...state, data: action.data };
    case 'SET_QUALITY':
      return { ...state, quality: action.quality };
    case 'SET_AI_DIAGNOSIS':
      return { ...state, aiDiagnosis: action.diagnosis };
    case 'SET_AI_SUGGESTIONS':
      return { ...state, aiSuggestions: action.suggestions };
    case 'ADD_LOG': {
      const entry: LogEntry = {
        id: state.cleanLog.length + 1,
        text: action.entry.text,
        type: action.entry.type,
        timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      };
      return { ...state, cleanLog: [...state.cleanLog, entry] };
    }
    case 'SET_KPIS':
      return { ...state, kpis: action.kpis };
    case 'SET_EXEC_REPORT':
      return { ...state, execReport: action.report };
    case 'SET_DICTIONARY':
      return { ...state, dictionary: action.dictionary };
    case 'SET_CHANGELOG':
      return { ...state, changelog: action.changelog };
    case 'SET_README':
      return { ...state, readme: action.readme };
    case 'RESET_DATA':
      if (state.originalData) {
        return {
          ...state,
          data: [...state.originalData.map(r => ({ ...r }))],
          cleanLog: [],
          quality: null,
          aiDiagnosis: null,
          aiSuggestions: [],
        };
      }
      return state;
    case 'RESET_QUALITY':
      return { ...state, quality: null, aiDiagnosis: null, aiSuggestions: [] };
    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<Action>;
} | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
